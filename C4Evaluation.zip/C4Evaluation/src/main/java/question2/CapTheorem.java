package question2;
/*
 * Q2. What is CAP theorem, discuss a scenario where CAP theorem helps you choose a technology over the other or helps you make a design decision.
 * 	CAP theorem is abbreviated as consistency, availability  and partition tolerance.
 * 	It is used to perform CRUD operation in database.
 * 	We cannot achieve all three properties of CAP.
 * We need to sacrifice any one property so that our data will be more feasible to use; 
 * 
 * */
public class CapTheorem {

}
