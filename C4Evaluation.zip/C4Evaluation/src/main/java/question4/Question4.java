package question4;

/*
 * a) What do you know about client server architecture?
 * 	Client server architecture is used to transfer data between user and server.
 * In most of the cases Browser will be our client.
 * But in some cases server becomes client and fetch data from other server.
 * Client request-data and Server responds to that request.
 * client server architecture is achieved using HTTP that is Hyper-text transfer protocol.
 * 	
 * 
 * b) What is caching, explain its use cases?
 * Cache is temporary memory which used to save frequently called method or function.
 * It is limited memory.
 * Using cache we can increase the speed of our application.
 * 
 * c) what are web sockets where it is used.
 * Web sockets are used to transfer data in bi-directional way. Which means it two way portal. 
 * Where we can get and post data simultaneously
 * 	
 * 
 * 
 * d) How are public and private keys used in encryption and decryption?
 * */

public class Question4 {

}
